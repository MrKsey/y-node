# The Netherlands Peers

Add connection strings from the below list to the `Peers: []` section of your
Yggdrasil configuration file to peer with these nodes.

* Amsterdam, Inferno Solutions public node, operated by [Werwolf](https://t.me/Werwolf2517) *bandwidth up to 1000 Mbps*
  * `tcp://vpn.itrus.su:7991`
  * `tls://vpn.itrus.su:7992`
  * `quic://vpn.itrus.su:7993`
  * `ws://vpn.itrus.su:7994`

* Amsterdam, public nodes, operated by [sergeysedoy97](https://t.me/sergeysedoy97)
  * `tcp://146.103.111.53:65535`
  * `quic://146.103.111.53:65535`
  * `tcp://[2a14:1e00:3:15c::]:65535`
  * `quic://[2a14:1e00:3:15c::]:65535`

  * `tcp://212.34.131.160:65535`
  * `quic://212.34.131.160:65535`
  * `tcp://[2a14:1e00:1:bae::]:65535`
  * `quic://[2a14:1e00:1:bae::]:65535`

  * `tcp://109.107.177.127:65535`
  * `quic://109.107.177.127:65535`
  * `tcp://[2a0d:8480:3:234c::]:65535`
  * `quic://[2a0d:8480:3:234c::]:65535`

  * `tcp://146.103.107.222:65535`
  * `quic://146.103.107.222:65535`
  * `tcp://[2a14:1e00:3:2b2::]:65535`
  * `quic://[2a14:1e00:3:2b2::]:65535`

  * `tcp://5.35.70.181:65535`
  * `quic://5.35.70.181:65535`
  * `tcp://[2a14:1e00:1:ecd::]:65535`
  * `quic://[2a14:1e00:1:ecd::]:65535`

  * `tcp://88.210.10.78:65535`
  * `quic://88.210.10.78:65535`
  * `tcp://[2a0d:8480:1:209e::]:65535`
  * `quic://[2a0d:8480:1:209e::]:65535`

  * `tcp://89.110.116.167:65535`
  * `quic://89.110.116.167:65535`
  * `tcp://[2a14:1e00:1:f3c::]:65535`
  * `quic://[2a14:1e00:1:f3c::]:65535`

* Amsterdam, public node, operated by [ThatMaidGuy](https://thatmaidguy.ru), 100 Mbit/s
  * `tcp://thatmaidguy.fvds.ru:7991`

* Kerkrade, VPS, operated by [Fijxu (nadeko.net)](https://nadeko.net), 1Gbit/s, DualStack (IPv4+IPv6)
  * `tcp://cirno.nadeko.net:44441`
  * `tls://cirno.nadeko.net:44442`
 
* Amsterdam, RoyaleHosting VPS, public node, operated by [Orbit173](https://github.com/Orbit173), 1Gbit/s
  * `tls://nl1.route172.de:443?key=000000002643ae27bad63e2a81f1d30554ce9ea634f5990062a9e079e23593cd`
  * `tcp://nl1.route172.de:65535?key=000000002643ae27bad63e2a81f1d30554ce9ea634f5990062a9e079e23593cd`
  * `quic://nl1.route172.de:65535?key=000000002643ae27bad63e2a81f1d30554ce9ea634f5990062a9e079e23593cd`
 
* Amsterdam, VPS, public node, operated by [oneeel5](https://github.com/oneeel5), 400 Mbit/s
  * `tls://5.252.118.13:443`
  * `tcp://5.252.118.13:65535`
  * `quic://5.252.118.13:65535`

* Netherlands, public node, DualStack (IPv4+IPv6)
  * `tcp://ygg.bruijn.nu:65535`
  * `quic://ygg.bruijn.nu:65535`
