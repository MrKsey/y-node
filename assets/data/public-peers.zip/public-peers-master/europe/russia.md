# Russia Peers

Operators of Yggdrasil public peers in Russia should consider joining the [Russian Meshnet](https://github.com/russian-meshnet/meshnet-chat-agenda/blob/master/README.md#чаты-и-мосты-в-разных-сетях) and [Yggdrasil RU](https://t.me/Yggdrasil_ru) community channels!

Add connection strings from the below list to the `Peers: []` section of your Yggdrasil configuration file to peer with these nodes.

### Moscow

* Moscow, home public node (MGTS internet provider), operated by [AveryanAlex](https://t.me/averyanalex), 200 Mbit/s, IPv4 Only
  * `tcp://ygg-msk-1.averyan.ru:8363`
  * `tls://ygg-msk-1.averyan.ru:8362`
  * `quic://ygg-msk-1.averyan.ru:8364`

* Moscow, vps public node, operated by [Nikat](https://t.me/nikat_meh)
  * `tcp://yggno.de:18226`
  * `tls://yggno.de:18227`
  * `tcp://188.225.9.167:18226`
  * `tls://188.225.9.167:18227`

* Moscow, public nodes, operated by [sergeysedoy97](https://t.me/sergeysedoy97)
  * `tcp://89.44.86.85:65535`
  * `quic://89.44.86.85:65535`
  * `tcp://[2a09:5302:ffff::132a]:65535`
  * `quic://[2a09:5302:ffff::132a]:65535`

  * `tcp://94.156.181.85:65535`
  * `quic://94.156.181.85:65535`

* Моscow, VPS public nodes operated by [gastarbeiter14](https://t.me/gastarbeiter14):
  * node1:
  * `tcp://45.147.200.202:12402`
  * `tcp://[2a00:b700::a:279]:12402`
  * `tls://45.147.200.202:443`
  * `tls://[2a00:b700::a:279]:443`
  * node2:
  * `tcp://45.95.202.21:12403`
  * `tcp://[2a09:5302:ffff::992]:12403`
  * `tls://45.95.202.21:443`
  * `tls://[2a09:5302:ffff::992]:443`

* Moscow, VPS, public node, operated by [Orbit173](https://github.com/Orbit173), 1 Gbit/s, IPv4/IPv6
  * `wss://assets.route172.de:443/api/request/media?key=00000000000da547036a01860a9e3a0476a525415801ec34f4e5b59fd6055b88`
 
* Moscow, VPS, public node, operated by [CERT](https://github.com/kzorin52), 10 Gbit/s, IPv4/IPv6
  * `tcp://ru2.cert.dev:7040`
  * `tls://ru2.cert.dev:7041`
  * `quic://ru2.cert.dev:7042`
  * `ws://ru2.cert.dev:7043`

* Moscow, VPS, public node, operated by [Dmitry Modder](https://github.com/dmitrymodder)
  * `wss://ygg.mvault.ru.net:443`

* Moscow, VPS public node, operated by [loskiq](mailto:loskiq@gmail.com)
  * `tcp://ygg-ru.lskd.pw:30041`
  * `tls://ygg-ru.lskd.pw:30042`
  * `quic://ygg-ru.lskd.pw:30043`
 
* Moscow, VPS public node, operated by [Dimoka113](https://i113d.ru), 1 Gbit/s, IPv4 only
  * `tcp://mskaeza.i113d.ru:12631`
  * `tls://mskaeza.i113d.ru:12632`
  * `quic://mskaeza.i113d.ru:12633`
  * `ws://mskaeza.i113d.ru:12634`

### Odintsovo

* Odintsovo, home public node, operated by [MedDevSystems](https://github.com/MedDevSystems), IPv4 only
  * `tls://ygg.med-dev-systems.ru:6221`

* Odintsovo, home public node, operated by [Cyberneural](https://t.me/cyberneural)
  * `tcp://u-neroit.ru:7000`

### Saint Petersburg

* Saint Petersburg, home user public node, operated by [paulll](https://paulll.cc), *rate-limited to 200 Mbit/s IPv4/IPv6*
  * `tcp://box.paulll.cc:13337`
  * `tls://box.paulll.cc:13338`
 
### Samara

* Samara, home user public node, operated by [Dimoka113](https://i113d.ru), *rate-limited to 600 Mbit/s IPv4 only
  * `tcp://server.i113d.ru:12631`
  * `tls://server.i113d.ru:12632`
  * `quic://server.i113d.ru:12633`
  * `ws://server.i113d.ru:12634`

### Omsk

* Omsk, RusHost public node, operated by [Werwolf](https://t.me/Werwolf2517) *bandwidth up to 100 Mbps*
  * `tcp://srv.itrus.su:7991`
  * `tls://srv.itrus.su:7992`
  * `quic://srv.itrus.su:7993`
  * `ws://srv.itrus.su:7994`

### Novosibirsk

* Novosibirsk, VPS at ADMAN, operated by [Saiv46](https://github.com/saiv46), IPv4 only
  * `quic://novosibirsk.mie.foundation:9952`

* Novosibirsk, home public node, operated by WipedLife 100mbit/s, IPv4 only
  * `tcp://37.192.232.33:8080`
  * `tls://37.192.232.33:442`

### Krasnoyarsk

* Krasnoyarsk, public node, operated by [multed](https://multed.com/about)
  * `tcp://itcom.multed.com:7991`
 
### Kemerovo

* Kemerovo, public node, 100mbit/s, IPv4 only
  * `tcp://kem.txlyre.website:1337`

### Yekaterinburg

* Yekaterinburg, home public node, operated by [Werwolf](https://t.me/Werwolf2517) *bandwidth up to 300 Mbps*
  * `tcp://ekb.itrus.su:7991`
  * `tls://ekb.itrus.su:7992`
  * `quic://ekb.itrus.su:7993`
  * `ws://ekb.itrus.su:7994`

### Rostov-on-Don

* Rostov-on-Don, home public node, operated by [lavacat](lavacat@disroot.org) *bandwidth up to 200 Mbit/s*
  * `tls://vix.duckdns.org:36014`
  * `quic://vix.duckdns.org:36014`
  * `wss://donotclickthis.link:443/api/v2/socket`

### Kursk

* Kursk, dual-stack, dual-home, operated by [cleverfox](https://github.com/cleverfox/)
  * `tls://kursk.cleverfox.org:15015`
  * `quic://kursk.cleverfox.org:15015`
  * `ws://kursk.cleverfox.org:15016`

### Vladivostok

* Vladivostok, operated by [evasil](https://github.com/evasil/), IPv4 only
  * `tcp://yg-vvo.magicum.net:29330`
  * `tls://yg-vvo.magicum.net:29331`
