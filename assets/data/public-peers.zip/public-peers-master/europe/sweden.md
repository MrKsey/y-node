# Sweden Peers

Add connection strings from the below list to the `Peers: []` section of your
Yggdrasil configuration file to peer with these nodes.

* Linköping, operated by [ananace](https://github.com/ananace) (@ace:kittenface.studio)
  * `tls://ygg.ace.ctrl-c.liu.se:9999?key=5636b3af4738c3998284c4805d91209cab38921159c66a6f359f3f692af1c908`
  * `tcp://ygg.ace.ctrl-c.liu.se:9998?key=5636b3af4738c3998284c4805d91209cab38921159c66a6f359f3f692af1c908`
  * `quic://ygg.ace.ctrl-c.liu.se:9997?key=5636b3af4738c3998284c4805d91209cab38921159c66a6f359f3f692af1c908`

* Stockholm, public node, operated by [sergeysedoy97](https://t.me/sergeysedoy97)
  * `tcp://77.91.84.76:65535`
  * `quic://77.91.84.76:65535`
  * `tcp://[2a12:5940:b1a0::2]:65535`
  * `quic://[2a12:5940:b1a0::2]:65535`

* Stockholm, public node, operated by [Skhron](https://skhron.eu/), 1 Gbit/s, Dual-Stack
  * `tcp://sto01.yggdrasil.hosted-by.skhron.eu:8883?key=ce8cfa43b8c9e71c1fe31832b39403f23166f2bac12d52c755d9ac68f55da81c`
  * `tls://sto01.yggdrasil.hosted-by.skhron.eu:8884?key=ce8cfa43b8c9e71c1fe31832b39403f23166f2bac12d52c755d9ac68f55da81c`
  * `quic://sto01.yggdrasil.hosted-by.skhron.eu:8885?key=ce8cfa43b8c9e71c1fe31832b39403f23166f2bac12d52c755d9ac68f55da81c`
  * `ws://sto01.yggdrasil.hosted-by.skhron.eu:8886?key=ce8cfa43b8c9e71c1fe31832b39403f23166f2bac12d52c755d9ac68f55da81c`

* Gothenburg, anonymous yggdrasil IXP, operated by sysop, residential
  * `tcp://sysop.link:555`
  * `quic://sysop.link:555`

* Stockholm, VPS, 300 Mbit/s, IPv4, operated by laerad
  * `tls://se.laerad.top:54001?key=29512833cbca43f1f0bb1833d0edcb45791e66f7955c577b57fd0fc78892e2f8`
  * `quic://se.laerad.top:54001?key=29512833cbca43f1f0bb1833d0edcb45791e66f7955c577b57fd0fc78892e2f8`
