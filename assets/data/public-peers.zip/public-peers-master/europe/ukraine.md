# Ukraine peers

Add connection strings from the below list to the `Peers: []` section of your
Yggdrasil configuration file to peer with these nodes.

* Kiev, operated by [mvvpt](mvvpt0@bigmir.net)
  * `tcp://78.27.153.163:33165`
  * `tls://78.27.153.163:33166`
  * `tls://78.27.153.163:3785`
  * `tls://78.27.153.163:3784`
  * `tls://78.27.153.163:179`
 
* Kiev, operated by [SunSung](git@sunsung.fun)
  * `quic://yggdrasil.sunsung.fun:4441`
  * `tcp://yggdrasil.sunsung.fun:4442`
  * `tls://yggdrasil.sunsung.fun:4443`
 
* Ivano-Frankivsk
  * `quic://176.117.187.69:64537`
  * `tcp://176.117.187.69:64536`
  * `tls://176.117.187.69:64535`

* Kharkiv, 1GbE, operated by [MeizFL](meizfl@proside.pp.ua)
  * `tls://server.meizfl.pp.ua:7783`
